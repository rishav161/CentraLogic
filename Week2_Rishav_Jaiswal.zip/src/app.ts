import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import pool from "./pgConfig";

const app = express();
const port = 3000;
app.use(bodyParser.json());

app.post('/order-block', async (req: Request, res: Response) => {
  try {
    const { items } = req.body;

    //LineNo is divisible by 3
    const filteredOrders = items.filter((item: any) => {
      if (item.OrderBlocks) {
        for (const block of item.OrderBlocks) {
          if (Array.isArray(block.lineNo)) {
            for (const lineNo of block.lineNo) {
              if (lineNo % 3 === 0) {
                return true;
              }
            }
          } else if (block.lineNo % 3 === 0) {
            return true;
          }
        }
      }
      return false;
    });

    //null values
    const orderIDs = filteredOrders.map((order: any) => order.orderID).filter((id: any) => id !== undefined && id !== null);

    // invalid ID
    if (orderIDs.length === 0) {
      return res.json({ 
        success: true, 
        message: 'No valid order IDs to store' });
    }

    // Store in the database
    for (const orderID of orderIDs) {
      try {
        await pool.query('INSERT INTO orders (orderID) VALUES ($1)', [orderID]);
      } catch (err) {
        console.log('Error inserting orderID:', orderID, err);
      
      }
    }

    res.json({ success: true, message: 'Order IDs successfully stored' });
  } catch (err) {
    console.log('Error processing orders:', err);
    res.status(500).json({ 
      success: false,
       message: 'Internal server error' 
      });
  }
});

// --------------------------Array Function Operation--------------------

app.post('/array-function', async (req: Request<any, any,{arr:number[]}>, res: Response) => {
  try {
    const { arr } = req.body;

    if (!arr || !Array.isArray(arr)) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    const exercise = {
      concat:arr.concat([11,12,13]),
      push:arr.push(12),
      pop:arr.pop(),
      map: arr.map((item: number) => item * 4),
      filter:arr.filter(item=>item%2===0),
      foreach:arr.forEach(item=>console.log(item)
      ),
      find:arr.find(item=>item>12),
      findindex:arr.findIndex(item=>item>10),
      some:arr.some(item=>item<0),
      every:arr.every(item=>item>0),
      includes:arr.includes(4),
      indexOf:arr.indexOf(20),
      lastIndexOf:arr.lastIndexOf(8),
      splice:arr.splice(2,1,6),
      slice:arr.slice(2,5),
      shift:arr.shift(),
      Unshift:arr.unshift(1),
      Flat:arr.flat(),
      join:arr.join('-'),
      tostring:arr.toString(),
      // split:arr.split(" "),
      // replace:arr.replace(4,5)

  

      
    };

    res.json(exercise);
  } catch (err) {
    console.log(err,'Internal Server Error');
  }


});

//------------------- STUDENTS DATA------------------

interface Student {
  name: string;
  age: number;
  grade: number;
}

const students: Student[] = [
  { name: "Alice", age: 20, grade: 75 },
  { name: "Bob", age: 22, grade: 85 },
  { name: "Charlie", age: 21, grade: 60 },
  { name: "David", age: 19, grade: 45 },
  { name: "Eve", age: 20, grade: 90 }
];

//  passed students
app.get('/passed-students', (req: Request, res: Response) => {
  const passedStudents = students.filter(student => student.grade >= 50);
  res.json(passedStudents);
});

//student names
app.get('/student-names', (req: Request, res: Response) => {
  const studentNames = students.map(student => student.name);
  res.json(studentNames);
});

// sort by grade
app.get('/sorted-grade', (req: Request, res: Response) => {
  const studentsSortedByGrade = students.slice().sort((a, b) => a.grade - b.grade);
  res.json(studentsSortedByGrade);
});

//  get average age of students
app.get('/average-age', (req: Request, res: Response) => {
  const totalAge = students.reduce((acc, student) => acc + student.age, 0);
  const averageAge = totalAge / students.length;
  res.json({ averageAge });
});





app.listen(port, () => {
  console.log(`Server started at ${port}`);
});