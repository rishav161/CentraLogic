import { Pool } from 'pg';
const pool = new Pool({
 user: 'postgres',
 host: 'localhost',
 database: "CentraLogic",
 password: "Jaiswal@1610" ,
 port: 5432,
});

const createTable = async ()=>{
    try{
        const query = `
      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        orderID INTEGER NOT NULL
      )`;
        await pool.query(query);
        console.log("Table created succefully OR already exist");
        
    }
    catch(err){
        console.log("error in table creation",err);
    }
    const TableCheck = async () => {
        try {
          await createTable();
          console.log('Table creation completed.');
        } catch (err) {
          console.log('An error occurred:', err);
        }
      };
      
      TableCheck();
        
}

export default pool;