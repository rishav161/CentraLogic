import express, { Request, Response } from 'express';
import { splitString, concatenateStrings, isLeapYear, handshake } from './logic';

const app = express();
const port = 8000;

app.get('/split/:string', (req: Request, res: Response) => {
  const { string } = req.params;
  const revisedString = splitString(string);
  res.json({ revisedString });
});

app.get('/concat/:string1/:string2', (req: Request, res: Response) => {
  const { string1, string2 } = req.params;
  const revisedString = concatenateStrings(string1, string2);
  res.json({ revisedString });
});

app.get('/leap/:year', (req: Request, res: Response) => {
  const { year } = req.params;
  const isLeap = isLeapYear(parseInt(year));
  res.json({ isLeapYear: isLeap });
});

app.get('/handshake/:code', (req: Request, res: Response) => {
  const { code } = req.params;
  const signals = handshake(parseInt(code));
  res.json({ signals });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});