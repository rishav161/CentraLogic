export function splitString(str: string): string {
    return str.replace(/\_/g, ' ');
  }
  
  export function concatenateStrings(str1: string, str2: string): string {
    return str1 + str2;
  }
  
  export function isLeapYear(year: number): boolean {
    if (year % 400 === 0) return true;
    if (year % 100 === 0) return false;
    return year % 4 === 0;
  }
  
  export function handshake(code: number): string[] {
    const signals = [];
    const actions = ['wink', 'double blink', 'close your eyes', 'jump'];
  
    for (let i = 0; i < 4; i++) {
      if (code & (1 << i)) {
        signals.push(actions[i]);
      }
    }
  
    if (code & (1 << 4)) {
      signals.reverse();
    }
  
    return signals;
  }